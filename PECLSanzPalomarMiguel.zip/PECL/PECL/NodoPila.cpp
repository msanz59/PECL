#include "NodoPila.hpp"
#include "Proceso.hpp"

NodoPila::NodoPila(Proceso v, NodoPila* sig)
{
	valor = v;
	siguiente = sig;
}

NodoPila::~NodoPila()
{
	
}


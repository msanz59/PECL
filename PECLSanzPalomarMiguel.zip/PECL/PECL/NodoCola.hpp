#include <iostream>
#include "Proceso.hpp"
#include <string>
using namespace std;

class NodoCola
{
public:
	NodoCola(Proceso v, NodoCola* sig = NULL);
	~NodoCola();



private:
	Proceso valor;
	NodoCola*siguiente;
	
	friend class Cola;
	
};

typedef NodoCola*pnodoCola;
	
	
	
	
